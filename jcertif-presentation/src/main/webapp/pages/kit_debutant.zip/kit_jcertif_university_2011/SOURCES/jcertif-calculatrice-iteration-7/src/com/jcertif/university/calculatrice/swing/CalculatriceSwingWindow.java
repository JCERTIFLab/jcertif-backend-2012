package com.jcertif.university.calculatrice.swing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;

import com.jcertif.university.calculatrice.exception.OperateurInconnuException;
import com.jcertif.university.calculatrice.service.CalculatriceCompletServiceImpl;
import com.jcertif.university.calculatrice.service.CalculatriceEntierService;
import com.jcertif.university.calculatrice.service.CalculatriceEntierServiceImpl;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CalculatriceSwingWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField zoneSaisie;
	private CalculatriceEntierService service = new CalculatriceEntierServiceImpl();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculatriceSwingWindow frame = new CalculatriceSwingWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CalculatriceSwingWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 275);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("1");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("1");
			}
		});
		button.setBounds(53, 66, 117, 29);
		contentPane.add(button);
		
		JButton button_1 = new JButton("2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("2");
			}
		});
		button_1.setBounds(167, 66, 117, 29);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("3");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("3");
			}
		});
		button_2.setBounds(286, 66, 117, 29);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("4");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("4");
			}
		});
		button_3.setBounds(53, 102, 117, 29);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("5");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("5");
			}
		});
		button_4.setBounds(167, 102, 117, 29);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("6");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("6");
			}
		});
		button_5.setBounds(286, 102, 117, 29);
		contentPane.add(button_5);
		
		JButton button_6 = new JButton("7");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("7");
			}
		});
		button_6.setBounds(53, 138, 117, 29);
		contentPane.add(button_6);
		
		JButton button_7 = new JButton("8");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("8");
			}
		});
		button_7.setBounds(167, 138, 117, 29);
		contentPane.add(button_7);
		
		JButton button_8 = new JButton("9");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("9");
			}
		});
		button_8.setBounds(286, 138, 117, 29);
		contentPane.add(button_8);
		
		JButton button_9 = new JButton("0");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("0");
			}
		});
		button_9.setBounds(167, 179, 117, 29);
		contentPane.add(button_9);
		
		final JButton button_10 = new JButton("=");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CalculatriceEntierService service = new CalculatriceCompletServiceImpl();
				try {
					int resultat = service.evaluerExpression(zoneSaisie.getText());
					zoneSaisie.setText("" + resultat);
				} catch (OperateurInconnuException e) {
					JOptionPane.showMessageDialog(button_10.getParent(), "Op�rateur inconnu");
				}
			}
		});
		button_10.setBounds(286, 179, 117, 29);
		contentPane.add(button_10);
		
		zoneSaisie = new JTextField();
		zoneSaisie.setBounds(60, 6, 413, 28);
		contentPane.add(zoneSaisie);
		zoneSaisie.setColumns(10);
		
		JButton button_11 = new JButton("+");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("+");
			}
		});
		button_11.setBounds(406, 66, 67, 29);
		contentPane.add(button_11);
		
		JButton button_12 = new JButton("-");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("-");
			}
		});
		button_12.setBounds(406, 102, 67, 29);
		contentPane.add(button_12);
		
		JButton btnX = new JButton("*");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("*");
			}
		});
		btnX.setBounds(406, 138, 67, 29);
		contentPane.add(btnX);
		
		JButton button_13 = new JButton("/");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouterTexte("/");
			}
		});
		button_13.setBounds(406, 179, 67, 29);
		contentPane.add(button_13);
		
		JButton btnToutEffacer = new JButton("TOUT EFFACER");
		btnToutEffacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				zoneSaisie.setText("");
			}
		});
		btnToutEffacer.setBounds(53, 179, 117, 29);
		contentPane.add(btnToutEffacer);
		
		JButton btnEffacer = new JButton("EFFACER");
		btnEffacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String texteSaisi = zoneSaisie.getText();
				if(texteSaisi != null && texteSaisi.length() >= 1){
					zoneSaisie.setText(texteSaisi.substring(0, texteSaisi.length() - 1));
				}
			}
		});
		btnEffacer.setBounds(356, 35, 117, 29);
		contentPane.add(btnEffacer);
	}
	
	private void ajouterTexte(String texte){
		zoneSaisie.setText(zoneSaisie.getText() + texte);
	}
}
