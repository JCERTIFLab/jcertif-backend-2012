package com.jcertif.university.calculatrice.main;

import java.util.Scanner;

import com.jcertif.university.calculatrice.service.CalculatriceCompletServiceImpl;
import com.jcertif.university.calculatrice.service.CalculatriceEntierService;

/**
 * Classe principale de la calculatrice en mode console.
 * 
 * @author rossi.oddet
 * 
 */
public class CalculatriceConsoleMain {

	/**
	 * @param args
	 *            argument pass� � la m�thode main
	 */
	public static void main(String[] args) {
		System.out.println("La calculatrice JCertif vous souhaite la bienvenue");

		// Initialisation de deux variables
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Veuillez saisir un entier");
		int var1 = sc.nextInt();
		System.out.println("Veuillez saisir un entier");
		int var2 = sc.nextInt();
		
		System.out.println("var1 = " + var1 + " et var2 = " + var2);

		// Utilisation de l'interface
		CalculatriceCompletServiceImpl service = new CalculatriceCompletServiceImpl();

		// Appel de la m�thode plus(int,int) de la classe
		// CalculatriceEntierServiceImpl
		int resultatAddition = service.plus(var1, var2);

		// Affichage du r�sultat de l'addition
		System.out.println("R�sultat de l'addition = " + resultatAddition);

		// Appel de la m�thode moins(int,int) de la classe
		// CalculatriceEntierServiceImpl
		int resultatSoustraction = service.moins(var1, var2);

		// Affichage du r�sultat de la soustraction
		System.out.println("R�sultat de la soustraction = " + resultatSoustraction);

		// Appel de la m�thode multiplier(int,int) de la classe
		// CalculatriceEntierServiceImpl
		int resultatMultiplication = service.multiplier(var1, var2);

		// Affichage du r�sultat de la multiplication
		System.out.println("R�sultat de la multiplication = " + resultatMultiplication);

		// Appel de la m�thode multiplier(int,int) de la classe
		// CalculatriceEntierServiceImpl
		int resultatDivision = service.diviser(var1, var2);

		// Affichage du r�sultat de la division
		System.out.println("R�sultat de la division = " + resultatDivision);

	}

}
