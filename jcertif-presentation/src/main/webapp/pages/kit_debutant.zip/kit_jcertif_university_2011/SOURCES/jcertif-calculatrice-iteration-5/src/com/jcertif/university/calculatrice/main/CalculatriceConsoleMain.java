package com.jcertif.university.calculatrice.main;

import java.util.Scanner;

import com.jcertif.university.calculatrice.service.CalculatriceCompletServiceImpl;
import com.jcertif.university.calculatrice.service.CalculatriceEntierService;

/**
 * Classe principale de la calculatrice en mode console.
 * 
 * @author rossi.oddet
 * 
 */
public class CalculatriceConsoleMain {

	/**
	 * @param args
	 *            argument pass� � la m�thode main
	 */
	public static void main(String[] args) {
		System.out.println("La calculatrice JCertif vous souhaite la bienvenue");

		// Utilisation de l'interface
		CalculatriceEntierService service = new CalculatriceCompletServiceImpl();

		// Initialisation de deux variables
		Scanner sc = new Scanner(System.in);

		String saisie = sc.next();

		while (!"exit".equals(saisie)) {
			int resultat = service.evaluerExpression(saisie);
			
			System.out.println("resultat = " + resultat);

			saisie = sc.next();
		}

		System.out.println("Aurevoir");

	}

	
}
