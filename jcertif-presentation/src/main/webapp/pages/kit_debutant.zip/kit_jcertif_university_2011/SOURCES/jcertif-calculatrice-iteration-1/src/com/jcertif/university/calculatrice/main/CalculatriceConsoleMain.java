package com.jcertif.university.calculatrice.main;

/**
 * Classe principale de la calculatrice en mode console.
 * 
 * @author rossi.oddet
 * 
 */
public class CalculatriceConsoleMain {

	/**
	 * @param args
	 *            argument pass� � la m�thode main
	 */
	public static void main(String[] args) {
		System.out.println("La calculatrice JCertif vous souhaite la bienvenue");
	}

}
